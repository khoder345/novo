# NOVO v4
المشروع يبني APK تلقائياً عبر GitHub Actions. الخطوات في رد Claude.
